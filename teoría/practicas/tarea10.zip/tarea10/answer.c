if(/*condition*/)
{

}
else
{

}
if(/*condition*/)
{
if(/*condition*/)
{

}
else
{

}

}
else
{
if(/*condition*/)
{

}

}
if(/*condition*/)
{
if(/*condition*/)
{

}

}
if(/*condition*/)
{

}
if(/*condition*/)
{

}
else
{
if(/*condition*/)
{

}

}
if(/*condition*/)
{

}
else
{

}


gcc ./ejer1/main.c -o ./ejer1/a.out
gcc ./ejer2/main.c -o ./ejer2/a.out
gcc ./ejer3/main.c -o ./ejer3/a.out
gcc ./ejer4/main.c -o ./ejer4/a.out
gcc ./ejer5/main.c -o ./ejer5/a.out
for ((VAR=1 ; VAR<=5 ; VAR++ ))
do
   python3 grapher.py "ejer$VAR"
done